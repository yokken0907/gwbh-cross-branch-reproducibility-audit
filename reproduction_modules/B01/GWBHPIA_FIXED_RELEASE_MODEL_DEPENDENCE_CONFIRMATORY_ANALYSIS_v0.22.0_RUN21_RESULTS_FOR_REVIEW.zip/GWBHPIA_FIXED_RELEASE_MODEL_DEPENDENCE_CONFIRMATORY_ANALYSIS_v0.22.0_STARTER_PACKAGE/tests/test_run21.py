
import itertools
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import run21


def test_exact_identity_order():
    x = np.arange(5, dtype=float)
    y = np.arange(5, dtype=float)
    result = run21.exact_permutation_test(x, y)
    assert result["permutation_count"] == 120
    assert np.isclose(result["observed_rho"], 1.0, rtol=0.0, atol=1e-15)
    assert np.isclose(result["exact_one_sided_p"], 1 / 120, rtol=0.0, atol=1e-15)
    assert np.isclose(result["exact_two_sided_p"], 2 / 120, rtol=0.0, atol=1e-15)


def test_config_is_frozen():
    config = json.loads((ROOT / "config/run21_config.json").read_text())
    assert config["cohort_size"] == 8
    assert config["exact_permutations"] == 40320
    assert config["alpha"] == 0.05
    assert config["primary_predictor"] == "summary_median_max_pair_s90"
    assert config["primary_response"] == "median_posterior_model_norm_W1"


def test_complete_inputs():
    frozen = pd.read_csv(ROOT / "inputs/FROZEN_MODEL_DEPENDENCE_COHORT.csv")
    progress = pd.read_csv(ROOT / "inputs/FROZEN_COHORT_PROGRESS_AFTER_RUN20.csv")
    events = pd.read_csv(ROOT / "inputs/CUMULATIVE_EVENT_MODEL_DEPENDENCE_SUMMARY.csv")
    posterior = pd.read_csv(ROOT / "inputs/CUMULATIVE_POSTERIOR_MODEL_PAIRWISE.csv")
    assert len(frozen) == 8
    assert len(events) == 8
    assert len(posterior) == 192
    assert posterior.groupby("event").size().eq(24).all()
    assert progress["status"].astype(str).str.startswith("COMPLETED_").sum() == 8
    assert set(frozen["event"]) == set(events["event"])


def test_all_cells_are_common():
    posterior = pd.read_csv(ROOT / "inputs/CUMULATIVE_POSTERIOR_MODEL_PAIRWISE.csv")
    counts = posterior.groupby(["model_a", "model_b", "parameter"])["event"].nunique()
    assert len(counts) == 24
    assert counts.eq(8).all()


def test_no_hdf5_or_network_dependency():
    config = json.loads((ROOT / "config/run21_config.json").read_text())
    assert config["hdf5_required"] is False
    assert config["network_required"] is False
    found = []
    for pattern in ("*.hdf5", "*.h5"):
        found.extend(ROOT.rglob(pattern))
    assert not found
