#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p logs outputs deliverables
STATUS=0

python3 -m pytest -q > logs/RUN21_TESTS.log 2>&1 || STATUS=2

if [ "$STATUS" -eq 0 ]; then
  python3 src/run21.py > logs/RUN21_MAIN.log 2>&1 || STATUS=2
fi

python3 src/finalize_package.py > logs/RUN21_FINALIZE.log 2>&1 || STATUS=2

exit "$STATUS"
