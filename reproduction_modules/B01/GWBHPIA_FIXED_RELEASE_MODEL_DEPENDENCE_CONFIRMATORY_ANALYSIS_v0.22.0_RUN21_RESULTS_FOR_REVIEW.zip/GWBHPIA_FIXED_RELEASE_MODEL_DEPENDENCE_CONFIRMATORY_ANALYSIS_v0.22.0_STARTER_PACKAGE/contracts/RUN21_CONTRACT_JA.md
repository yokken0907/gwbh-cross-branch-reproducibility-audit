# RUN21 凍結ホールドアウトexact確認契約

## 入力
RUN17の開始前に凍結した8事象と、RUN17–RUN20で得た固定GWTC-4.0 v3の累積結果を使用する。
RUN20外部監査後にのみ本RUNを実行する。

## 主確認
- 説明変数：summary_median_max_pair_s90
- 応答変数：median_posterior_model_norm_W1
- 統計量：Spearman順位相関 rho
- 方向：正
- p値：応答8値の全8! = 40,320順列を列挙したexact片側p値
- alpha：0.05
- 支持条件：rho > 0 かつ exact片側p <= 0.05

全順列を列挙するため、plus-one補正は使用しない。

## 事前指定感度監査
- balanced observed W1を応答にした同じexact検定
- 全8事象共通のmodel-pair×parameterセルのみを使った応答
- exact両側p値
- Kendall tau-b
- leave-one-event-out Spearman範囲
- 四分位層別中央値

## 判定語
支持条件成立：
SUPPORTED_IN_FROZEN_HOLDOUT

不成立：
NOT_SUPPORTED_IN_FROZEN_HOLDOUT

## 境界
支持される場合でも、意味は次に限定する。

GWTC-4.0 v3要約表での3解析モデル間変動順位が、
凍結8事象におけるposterior sample上の公開解析チェーン依存性順位を追跡した。

以下は主張しない。
- 純粋な波形誤差の測定
- 特定モデルの優劣
- ブラックホール新物理
- 観測異常
- GWTC-4全体への無条件一般化
- metadata差の因果寄与率
