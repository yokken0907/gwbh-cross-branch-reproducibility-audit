# GWBH-PIA RUN21

固定GWTC-4.0 v3モデル依存性の、凍結8事象exact確認。

HDF5、ネットワーク、追加ダウンロードは不要。
実行：`bash run_run21.sh`
