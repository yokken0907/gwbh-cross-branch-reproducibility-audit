
from __future__ import annotations

import csv
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def excluded(relative: str) -> bool:
    normalized = "/" + relative.replace("\\", "/") + "/"
    return "/.pytest_cache/" in normalized or "/__pycache__/" in normalized


def main() -> None:
    files = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file()
        and not excluded(str(path.relative_to(ROOT)))
        and path.name not in {"MANIFEST.csv", "SHA256SUMS.csv"}
        and not str(path.relative_to(ROOT)).startswith("deliverables/")
    )

    rows = [
        {
            "path": str(path.relative_to(ROOT)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        for path in files
    ]
    for name in ("MANIFEST.csv", "SHA256SUMS.csv"):
        with (ROOT / name).open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=["path", "bytes", "sha256"],
            )
            writer.writeheader()
            writer.writerows(rows)

    files += [ROOT / "MANIFEST.csv", ROOT / "SHA256SUMS.csv"]
    output = (
        ROOT
        / "deliverables"
        / "GWBHPIA_FIXED_RELEASE_MODEL_DEPENDENCE_CONFIRMATORY_ANALYSIS_v0.22.0_RUN21_RESULTS_FOR_REVIEW.zip"
    )
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(files):
            archive.write(path, arcname=f"{ROOT.name}/{path.relative_to(ROOT)}")

    digest = sha256(output)
    Path(str(output) + ".sha256").write_text(
        f"{digest}  {output.name}\n",
        encoding="utf-8",
    )
    print(output)
    print(digest)


if __name__ == "__main__":
    main()
