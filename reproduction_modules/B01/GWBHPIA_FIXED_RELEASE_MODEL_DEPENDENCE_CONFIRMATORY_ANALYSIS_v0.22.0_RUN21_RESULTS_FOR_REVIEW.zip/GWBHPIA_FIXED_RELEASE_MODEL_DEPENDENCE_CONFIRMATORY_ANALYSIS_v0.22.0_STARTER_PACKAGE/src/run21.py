
from __future__ import annotations

import datetime as dt
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, rankdata, spearmanr

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def rho(x, y) -> float:
    return float(spearmanr(np.asarray(x, dtype=float), np.asarray(y, dtype=float)).statistic)


def exact_permutation_test(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) != len(y):
        raise ValueError("x and y must have equal length")

    rank_x = rankdata(x, method="average")
    rank_y = rankdata(y, method="average")
    if len(np.unique(rank_x)) != len(rank_x) or len(np.unique(rank_y)) != len(rank_y):
        raise ValueError("exact permutation implementation requires tie-free ranks")

    centered_x = rank_x - rank_x.mean()
    centered_y = rank_y - rank_y.mean()
    denominator = float(np.sqrt(np.sum(centered_x**2) * np.sum(centered_y**2)))
    observed = float(np.dot(centered_x, centered_y) / denominator)

    values = np.empty(math.factorial(len(y)), dtype=float)
    greater_equal = 0
    absolute_greater_equal = 0

    for index, permutation in enumerate(itertools.permutations(range(len(y)))):
        statistic = float(np.dot(centered_x, centered_y[list(permutation)]) / denominator)
        values[index] = statistic
        if statistic >= observed - 1e-15:
            greater_equal += 1
        if abs(statistic) >= abs(observed) - 1e-15:
            absolute_greater_equal += 1

    total = len(values)
    return {
        "observed_rho": observed,
        "permutation_count": total,
        "one_sided_extreme_count": greater_equal,
        "exact_one_sided_p": greater_equal / total,
        "two_sided_extreme_count": absolute_greater_equal,
        "exact_two_sided_p": absolute_greater_equal / total,
        "permutation_statistics": values,
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    config = json.loads((ROOT / "config/run21_config.json").read_text())
    frozen = pd.read_csv(ROOT / "inputs/FROZEN_MODEL_DEPENDENCE_COHORT.csv")
    progress = pd.read_csv(ROOT / "inputs/FROZEN_COHORT_PROGRESS_AFTER_RUN20.csv")
    events = pd.read_csv(ROOT / "inputs/CUMULATIVE_EVENT_MODEL_DEPENDENCE_SUMMARY.csv")
    posterior = pd.read_csv(ROOT / "inputs/CUMULATIVE_POSTERIOR_MODEL_PAIRWISE.csv")

    errors = []
    if len(frozen) != config["cohort_size"] or frozen["event"].nunique() != config["cohort_size"]:
        errors.append("frozen cohort is not eight unique events")
    if len(events) != config["cohort_size"] or events["event"].nunique() != config["cohort_size"]:
        errors.append("event summary is not eight unique events")
    if len(posterior) != config["cohort_size"] * 24:
        errors.append("posterior pairwise row count is not 192")
    if int(progress["status"].astype(str).str.startswith("COMPLETED_").sum()) != config["cohort_size"]:
        errors.append("not all frozen events are completed")
    if set(frozen["event"]) != set(events["event"]):
        errors.append("frozen cohort and event summary differ")

    cell_keys = ["model_a", "model_b", "parameter"]
    event_cell_counts = posterior.groupby("event").size()
    if not (event_cell_counts == 24).all():
        errors.append("one or more events do not have 24 posterior cells")

    if errors:
        pd.DataFrame({"error": errors}).to_csv(OUT / "ERROR_LEDGER.csv", index=False)
        return 2

    ordered = events.sort_values(config["primary_predictor"]).reset_index(drop=True)
    x = ordered[config["primary_predictor"]].to_numpy(dtype=float)
    y = ordered[config["primary_response"]].to_numpy(dtype=float)
    y_balanced = ordered["median_balanced_observed_W1"].to_numpy(dtype=float)

    primary = exact_permutation_test(x, y)
    balanced = exact_permutation_test(x, y_balanced)

    common_counts = posterior.groupby(cell_keys)["event"].nunique()
    common_cells = common_counts[common_counts == config["cohort_size"]].index.tolist()

    common_response = []
    for event in ordered["event"]:
        indexed = posterior[posterior["event"] == event].set_index(cell_keys)
        common_response.append(
            float(np.median([indexed.loc[cell, "full_norm_W1"] for cell in common_cells]))
        )
    common = exact_permutation_test(x, common_response)

    kendall = kendalltau(x, y)

    loo_rows = []
    for index, row in ordered.iterrows():
        keep = np.arange(len(ordered)) != index
        loo_rows.append(
            {
                "removed_event": row["event"],
                "removed_stratum": row["stratum"],
                "spearman_rho": rho(x[keep], y[keep]),
            }
        )
    loo = pd.DataFrame(loo_rows)

    ordered["predictor_rank"] = rankdata(x, method="average")
    ordered["response_rank"] = rankdata(y, method="average")
    ordered["rank_difference"] = ordered["response_rank"] - ordered["predictor_rank"]
    ordered["common_cell_median_norm_W1"] = common_response
    ordered.to_csv(OUT / "EVENT_RANK_TABLE.csv", index=False)

    pd.DataFrame(loo_rows).to_csv(OUT / "LEAVE_ONE_EVENT_OUT.csv", index=False)

    stratum_summary = (
        ordered.groupby("stratum", as_index=False, observed=True)
        .agg(
            events=("event", "size"),
            median_predictor=(config["primary_predictor"], "median"),
            median_primary_response=(config["primary_response"], "median"),
            median_balanced_response=("median_balanced_observed_W1", "median"),
        )
    )
    stratum_order = {"Q1_LOW": 1, "Q2_LOWMID": 2, "Q3_HIGHMID": 3, "Q4_HIGH": 4}
    stratum_summary["order"] = stratum_summary["stratum"].map(stratum_order)
    stratum_summary = stratum_summary.sort_values("order").drop(columns="order")
    stratum_summary.to_csv(OUT / "STRATUM_SUMMARY.csv", index=False)

    common_cell_frame = pd.DataFrame(common_cells, columns=cell_keys)
    common_cell_frame.to_csv(OUT / "COMMON_MODEL_PAIR_PARAMETER_CELLS.csv", index=False)

    unique_statistics, counts = np.unique(
        primary["permutation_statistics"],
        return_counts=True,
    )
    pd.DataFrame(
        {
            "spearman_rho": unique_statistics,
            "permutation_count": counts,
        }
    ).to_csv(OUT / "PRIMARY_PERMUTATION_DISTRIBUTION.csv", index=False)

    supported = (
        primary["observed_rho"] > 0
        and primary["exact_one_sided_p"] <= config["alpha"]
    )
    verdict = (
        "SUPPORTED_IN_FROZEN_HOLDOUT"
        if supported
        else "NOT_SUPPORTED_IN_FROZEN_HOLDOUT"
    )

    results = {
        "primary": {
            key: value
            for key, value in primary.items()
            if key != "permutation_statistics"
        },
        "balanced_sensitivity": {
            key: value
            for key, value in balanced.items()
            if key != "permutation_statistics"
        },
        "common_cell_sensitivity": {
            **{
                key: value
                for key, value in common.items()
                if key != "permutation_statistics"
            },
            "common_cell_count": len(common_cells),
        },
        "kendall_tau_b": {
            "tau": float(kendall.statistic),
            "p_value": float(kendall.pvalue),
        },
        "leave_one_event_out": {
            "minimum_rho": float(loo["spearman_rho"].min()),
            "maximum_rho": float(loo["spearman_rho"].max()),
        },
    }
    (OUT / "CONFIRMATORY_RESULTS.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    report = {
        "project_id": config["project_id"],
        "run_id": config["run_id"],
        "completed_at_utc": dt.datetime.now(dt.timezone.utc)
        .replace(microsecond=0)
        .isoformat(),
        "verdict": verdict,
        "support_rule": config["support_rule"],
        "alpha": config["alpha"],
        "cohort_size": config["cohort_size"],
        "primary_spearman_rho": primary["observed_rho"],
        "primary_exact_one_sided_p": primary["exact_one_sided_p"],
        "primary_exact_two_sided_p": primary["exact_two_sided_p"],
        "primary_permutations": primary["permutation_count"],
        "balanced_spearman_rho": balanced["observed_rho"],
        "balanced_exact_one_sided_p": balanced["exact_one_sided_p"],
        "common_cell_count": len(common_cells),
        "common_cell_spearman_rho": common["observed_rho"],
        "common_cell_exact_one_sided_p": common["exact_one_sided_p"],
        "kendall_tau_b": float(kendall.statistic),
        "kendall_p_value": float(kendall.pvalue),
        "leave_one_out_minimum_rho": float(loo["spearman_rho"].min()),
        "leave_one_out_maximum_rho": float(loo["spearman_rho"].max()),
        "errors": 0,
        "hdf5_used": False,
        "network_used": False,
        "causal_attribution_performed": False,
        "population_generalization_performed": False,
        "scope": (
            "frozen eight-event holdout confirmation that v3 summary-table "
            "model-spread ranks track posterior public-analysis-chain dependence ranks"
        ),
    }
    (OUT / "RUN21_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    pd.DataFrame(columns=["error"]).to_csv(OUT / "ERROR_LEDGER.csv", index=False)

    closure_text = f"""# RUN21 凍結ホールドアウト確認報告

## 判定
**{verdict}**

## 主確認
- Spearman rho: {primary['observed_rho']:.12f}
- exact片側p値: {primary['exact_one_sided_p']:.12f}
- exact両側p値: {primary['exact_two_sided_p']:.12f}
- 全順列: {primary['permutation_count']:,}
- alpha: {config['alpha']}

## 感度監査
- balanced response rho: {balanced['observed_rho']:.12f}
- balanced exact片側p: {balanced['exact_one_sided_p']:.12f}
- 共通セル数: {len(common_cells)}
- 共通セルrho: {common['observed_rho']:.12f}
- 共通セルexact片側p: {common['exact_one_sided_p']:.12f}
- Kendall tau-b: {float(kendall.statistic):.12f}
- leave-one-event-out rho: {loo['spearman_rho'].min():.12f}–{loo['spearman_rho'].max():.12f}

## 限定的結論
GWTC-4.0 v3要約表での3解析モデル間変動順位は、
事前凍結した8事象においてposterior sample上の
公開解析チェーン依存性順位を強く追跡した。

この結果は純粋な波形モデル誤差、モデル優劣、
ブラックホール新物理、観測異常を示さない。
"""
    (OUT / "CLOSURE_REPORT_JA.md").write_text(closure_text, encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
