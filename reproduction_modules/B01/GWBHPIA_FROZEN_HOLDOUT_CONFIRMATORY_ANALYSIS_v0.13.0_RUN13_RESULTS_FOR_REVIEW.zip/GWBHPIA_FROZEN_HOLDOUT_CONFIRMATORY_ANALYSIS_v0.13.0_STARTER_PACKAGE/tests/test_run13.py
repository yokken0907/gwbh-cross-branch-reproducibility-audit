
import csv
import itertools
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import run13


def test_exact_monotonic_five():
    x = np.arange(5, dtype=float)
    result = run13.exact_spearman_permutation(x, x)
    assert abs(result["rho"] - 1.0) < 1e-12
    assert result["permutations"] == 120
    assert result["exact_one_sided_p"] == 1 / 120


def test_frozen_cohort_complete():
    freeze = pd.read_csv(ROOT / "inputs" / "HOLDOUT_COHORT_FREEZE.csv")
    progress = pd.read_csv(ROOT / "inputs" / "HOLDOUT_PROGRESS_AFTER_RUN12.csv")
    assert len(freeze) == 8
    assert freeze["event"].nunique() == 8
    assert progress["event"].nunique() == 8
    assert progress["status"].astype(str).str.startswith("COMPLETED_").all()


def test_primary_summary_has_eight_events():
    cumulative = pd.read_csv(ROOT / "inputs" / "CUMULATIVE_HOLDOUT_EVENT_SUMMARY.csv")
    primary = cumulative[cumulative["pair"] == "v1_to_v2"]
    assert len(primary) == 8
    assert primary["event"].nunique() == 8


def test_detailed_rows_cover_all_events():
    details = pd.read_csv(
        ROOT / "inputs" / "ALL_BATCH_BALANCED_POSTERIOR_ROBUSTNESS.csv"
    )
    primary = details[
        (details["pair"] == "v1_to_v2")
        & (details["analysis_class"] == "PRIMARY_INDIVIDUAL_MODEL")
    ]
    assert primary["event"].nunique() == 8
    assert len(primary) == 152


def test_no_hdf5_inputs():
    assert not list(ROOT.rglob("*.hdf5"))
    assert not list(ROOT.rglob("*.h5"))
