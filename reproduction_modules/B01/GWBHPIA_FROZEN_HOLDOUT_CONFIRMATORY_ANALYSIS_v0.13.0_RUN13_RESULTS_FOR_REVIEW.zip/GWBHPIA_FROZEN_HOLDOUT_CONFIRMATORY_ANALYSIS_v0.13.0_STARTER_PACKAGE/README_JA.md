# GWBH-PIA RUN13

凍結済み8事象ホールドアウトの主確認を一度だけ実行する小容量パッケージ。

- 新規ダウンロードなし
- HDF5不要
- strain不要
- 入力はRUN09–RUN12の小容量CSVのみ
- 実行：`bash run_run13.sh`

RUN13結果ZIPを保存すれば、RUN12の約1.06GBキャッシュは不要。
