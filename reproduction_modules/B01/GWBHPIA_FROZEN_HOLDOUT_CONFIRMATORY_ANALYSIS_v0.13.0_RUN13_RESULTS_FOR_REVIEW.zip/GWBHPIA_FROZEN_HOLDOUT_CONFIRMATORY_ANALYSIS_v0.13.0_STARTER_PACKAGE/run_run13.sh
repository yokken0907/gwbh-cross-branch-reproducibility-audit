#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p logs outputs deliverables
STATUS=0
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv > logs/RUN13_VENV.log 2>&1 || STATUS=2
fi
if [ "$STATUS" -eq 0 ]; then
  .venv/bin/python -m pip install --upgrade pip > logs/RUN13_PIP.log 2>&1 || STATUS=2
  .venv/bin/python -m pip install -r environment/requirements.txt >> logs/RUN13_PIP.log 2>&1 || STATUS=2
fi
if [ "$STATUS" -eq 0 ]; then
  .venv/bin/python -m pytest -q > logs/RUN13_TESTS.log 2>&1 || STATUS=2
fi
if [ "$STATUS" -eq 0 ]; then
  .venv/bin/python src/run13.py > logs/RUN13_MAIN.log 2>&1 || STATUS=2
fi
if [ -x .venv/bin/python ]; then
  .venv/bin/python src/finalize_package.py > logs/RUN13_FINALIZE.log 2>&1 || STATUS=2
fi
exit "$STATUS"
