
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, rankdata

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def spearman_rho(x, y) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rx = rankdata(x, method="average")
    ry = rankdata(y, method="average")
    return float(np.corrcoef(rx, ry)[0, 1])


def exact_spearman_permutation(x, y) -> dict:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rx = rankdata(x, method="average").astype(float)
    ry = rankdata(y, method="average").astype(float)
    rx_centered = rx - rx.mean()
    ry_centered = ry - ry.mean()
    denominator = float(np.sqrt(np.dot(rx_centered, rx_centered) * np.dot(ry_centered, ry_centered)))
    if denominator <= 0:
        raise ValueError("Spearman correlation is undefined for a constant vector")
    observed = float(np.dot(rx_centered, ry_centered) / denominator)
    null = np.empty(math.factorial(len(y)), dtype=float)
    for index, permutation in enumerate(itertools.permutations(ry_centered.tolist())):
        null[index] = float(np.dot(rx_centered, permutation) / denominator)
    tolerance = 1e-15
    greater_count = int(np.sum(null >= observed - tolerance))
    two_sided_count = int(np.sum(np.abs(null) >= abs(observed) - tolerance))
    return {
        "rho": observed,
        "permutations": int(len(null)),
        "greater_or_equal_count": greater_count,
        "two_sided_extreme_count": two_sided_count,
        "exact_one_sided_p": float(greater_count / len(null)),
        "exact_two_sided_p": float(two_sided_count / len(null)),
        "null_q025": float(np.quantile(null, 0.025)),
        "null_q50": float(np.quantile(null, 0.5)),
        "null_q975": float(np.quantile(null, 0.975)),
    }


def validate_inputs(freeze, progress, cumulative, details, sources, cfg):
    errors = []

    if len(freeze) != cfg["frozen_cohort_size"]:
        errors.append(f"freeze row count {len(freeze)}")
    if freeze["event"].nunique() != cfg["frozen_cohort_size"]:
        errors.append("freeze events are not unique")
    if not (freeze["posterior_outcome_seen_at_freeze"].astype(str).str.lower() == "false").all():
        errors.append("posterior_outcome_seen_at_freeze is not uniformly false")

    strata = freeze.groupby("stratum", observed=True)["event"].nunique().to_dict()
    expected_strata = {"Q1_LOW": 2, "Q2_LOWMID": 2, "Q3_HIGHMID": 2, "Q4_HIGH": 2}
    if strata != expected_strata:
        errors.append(f"strata mismatch: {strata}")

    if progress["event"].nunique() != cfg["frozen_cohort_size"]:
        errors.append("progress does not cover 8 unique events")
    if not progress["status"].astype(str).str.startswith("COMPLETED_").all():
        errors.append("not all frozen events are completed")

    primary = cumulative[cumulative["pair"] == cfg["primary_pair"]]
    if len(primary) != cfg["frozen_cohort_size"] or primary["event"].nunique() != cfg["frozen_cohort_size"]:
        errors.append("primary cumulative table is not one row per frozen event")

    if set(primary["event"]) != set(freeze["event"]):
        errors.append("primary events differ from frozen cohort")

    detailed_primary = details[
        (details["pair"] == cfg["primary_pair"])
        & (details["analysis_class"] == "PRIMARY_INDIVIDUAL_MODEL")
    ]
    if detailed_primary["event"].nunique() != cfg["frozen_cohort_size"]:
        errors.append("detailed primary rows do not cover all events")

    recalculated = (
        detailed_primary.groupby("event", as_index=False)
        .agg(
            recalculated_median_full_norm_W1=("full_norm_W1", "median"),
            recalculated_median_balanced_observed_W1=("observed_w1_median", "median"),
            recalculated_rows=("full_norm_W1", "size"),
        )
    )
    check = primary.merge(recalculated, on="event", how="outer")
    max_full_diff = float(
        np.max(np.abs(check["median_full_norm_W1"] - check["recalculated_median_full_norm_W1"]))
    )
    max_balanced_diff = float(
        np.max(
            np.abs(
                check["median_balanced_observed_W1"]
                - check["recalculated_median_balanced_observed_W1"]
            )
        )
    )
    if max_full_diff > 1e-12:
        errors.append(f"full W1 summary mismatch: {max_full_diff}")
    if max_balanced_diff > 1e-12:
        errors.append(f"balanced W1 summary mismatch: {max_balanced_diff}")

    source_verification = []
    for row in sources.to_dict("records"):
        source_verification.append({
            **row,
            "listed_sha256_length_ok": len(str(row["sha256"])) == 64,
            "listed_bytes_positive": int(row["bytes"]) > 0,
        })
    source_verification = pd.DataFrame(source_verification)
    if not source_verification["listed_sha256_length_ok"].all():
        errors.append("invalid source SHA-256 length")
    if not source_verification["listed_bytes_positive"].all():
        errors.append("invalid source byte count")

    return errors, check, source_verification, max_full_diff, max_balanced_diff


def event_table(freeze, cumulative, cfg):
    primary = cumulative[cumulative["pair"] == cfg["primary_pair"]].copy()
    columns = [
        "event", "stratum", "median_s90", "max_s90", "mean_s90",
        "selection_seed", "posterior_outcome_seen_at_freeze",
    ]
    table = freeze[columns].merge(primary, on=["event", "stratum"], how="inner")
    return table.sort_values("median_s90").reset_index(drop=True)


def common_cell_sensitivity(details, freeze, cfg):
    primary = details[
        (details["pair"] == cfg["primary_pair"])
        & (details["analysis_class"] == "PRIMARY_INDIVIDUAL_MODEL")
    ].copy()
    coverage = (
        primary.groupby(["analysis", "parameter"], as_index=False)
        .agg(n_events=("event", "nunique"))
    )
    common = coverage[coverage["n_events"] == cfg["frozen_cohort_size"]][
        ["analysis", "parameter"]
    ]
    restricted = primary.merge(common, on=["analysis", "parameter"], how="inner")
    event = (
        restricted.groupby("event", as_index=False)
        .agg(
            common_cell_median_full_norm_W1=("full_norm_W1", "median"),
            common_cell_median_balanced_observed_W1=("observed_w1_median", "median"),
            common_cell_rows=("full_norm_W1", "size"),
        )
        .merge(freeze[["event", "median_s90"]], on="event", how="inner")
    )
    return coverage, common, event


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    cfg = json.loads((ROOT / "config" / "run13_config.json").read_text())
    freeze = pd.read_csv(ROOT / "inputs" / "HOLDOUT_COHORT_FREEZE.csv")
    progress = pd.read_csv(ROOT / "inputs" / "HOLDOUT_PROGRESS_AFTER_RUN12.csv")
    cumulative = pd.read_csv(ROOT / "inputs" / "CUMULATIVE_HOLDOUT_EVENT_SUMMARY.csv")
    details = pd.read_csv(ROOT / "inputs" / "ALL_BATCH_BALANCED_POSTERIOR_ROBUSTNESS.csv")
    sources = pd.read_csv(ROOT / "inputs" / "SOURCE_BATCH_PACKAGES.csv")

    errors, summary_check, source_check, max_full_diff, max_balanced_diff = validate_inputs(
        freeze, progress, cumulative, details, sources, cfg
    )
    write_csv(OUT / "SUMMARY_RECALCULATION_CHECK.csv", summary_check)
    write_csv(OUT / "SOURCE_PACKAGE_VERIFICATION.csv", source_check)

    if errors:
        pd.DataFrame({"error": errors}).to_csv(OUT / "ERROR_LEDGER.csv", index=False)
        (OUT / "RUN_STATUS.json").write_text(
            json.dumps(
                {"verdict": "HOLD_INPUT_VALIDATION_FAILED", "errors": len(errors)},
                indent=2,
            )
            + "\n"
        )
        return 2

    table = event_table(freeze, cumulative, cfg)
    write_csv(OUT / "CONFIRMATORY_EVENT_TABLE.csv", table)

    primary = exact_spearman_permutation(
        table[cfg["primary_predictor"]],
        table[cfg["primary_outcome"]],
    )
    balanced = exact_spearman_permutation(
        table[cfg["primary_predictor"]],
        table["median_balanced_observed_W1"],
    )

    tau = kendalltau(
        table[cfg["primary_predictor"]],
        table[cfg["primary_outcome"]],
        variant="b",
    )

    coverage, common_cells, common_event = common_cell_sensitivity(details, freeze, cfg)
    write_csv(OUT / "ANALYSIS_PARAMETER_COVERAGE.csv", coverage)
    write_csv(OUT / "COMMON_ANALYSIS_PARAMETER_CELLS.csv", common_cells)
    write_csv(OUT / "COMMON_CELL_EVENT_TABLE.csv", common_event)

    common_full = exact_spearman_permutation(
        common_event["median_s90"],
        common_event["common_cell_median_full_norm_W1"],
    )
    common_balanced = exact_spearman_permutation(
        common_event["median_s90"],
        common_event["common_cell_median_balanced_observed_W1"],
    )

    leave_one_out = []
    for event in table["event"]:
        sub = table[table["event"] != event]
        leave_one_out.append({
            "excluded_event": event,
            "n": len(sub),
            "rho": spearman_rho(
                sub[cfg["primary_predictor"]],
                sub[cfg["primary_outcome"]],
            ),
        })
    leave_one_out = pd.DataFrame(leave_one_out)
    write_csv(OUT / "LEAVE_ONE_EVENT_OUT.csv", leave_one_out)

    strata = (
        table.groupby("stratum", observed=True, as_index=False)
        .agg(
            events=("event", "nunique"),
            median_summary_s90=("median_s90", "median"),
            median_posterior_W1=("median_full_norm_W1", "median"),
            median_balanced_W1=("median_balanced_observed_W1", "median"),
            total_CLEAR_ABOVE_NULL=("CLEAR_ABOVE_NULL", "sum"),
            total_rows=("rows", "sum"),
        )
    )
    order = {"Q1_LOW": 1, "Q2_LOWMID": 2, "Q3_HIGHMID": 3, "Q4_HIGH": 4}
    strata["order"] = strata["stratum"].map(order)
    strata = strata.sort_values("order")
    write_csv(OUT / "STRATUM_SUMMARY.csv", strata)

    supported = (
        primary["rho"] > 0
        and primary["exact_one_sided_p"] <= cfg["alpha"]
    )
    verdict = (
        "SUPPORTED_IN_FROZEN_HOLDOUT"
        if supported
        else "NOT_SUPPORTED_IN_FROZEN_HOLDOUT"
    )

    report = {
        "project_id": cfg["project_id"],
        "run_id": cfg["run_id"],
        "completed_at_utc": dt.datetime.now(dt.timezone.utc)
        .replace(microsecond=0)
        .isoformat(),
        "verdict": verdict,
        "frozen_events": int(len(table)),
        "primary_predictor": cfg["primary_predictor"],
        "primary_outcome": cfg["primary_outcome"],
        "primary_rho": primary["rho"],
        "primary_exact_one_sided_p": primary["exact_one_sided_p"],
        "primary_exact_two_sided_p": primary["exact_two_sided_p"],
        "primary_permutations": primary["permutations"],
        "alpha": cfg["alpha"],
        "kendall_tau_b": float(tau.statistic),
        "kendall_asymptotic_p": float(tau.pvalue),
        "balanced_rho": balanced["rho"],
        "balanced_exact_one_sided_p": balanced["exact_one_sided_p"],
        "common_cells": int(len(common_cells)),
        "common_cell_rho": common_full["rho"],
        "common_cell_exact_one_sided_p": common_full["exact_one_sided_p"],
        "common_cell_balanced_rho": common_balanced["rho"],
        "common_cell_balanced_exact_one_sided_p": common_balanced["exact_one_sided_p"],
        "leave_one_out_rho_min": float(leave_one_out["rho"].min()),
        "leave_one_out_rho_max": float(leave_one_out["rho"].max()),
        "summary_recalculation_max_full_diff": max_full_diff,
        "summary_recalculation_max_balanced_diff": max_balanced_diff,
        "input_errors": 0,
        "external_downloads": 0,
        "raw_hdf5_required": False,
        "strain_downloaded": False,
        "fully_blinded_preregistered_trial": False,
        "scope": (
            "bounded confirmation that RUN03 summary drift ranks track v1-to-v2 "
            "posterior distribution drift in the frozen eight-event holdout"
        ),
    }
    (OUT / "RUN13_CONFIRMATORY_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    report_md = f"""# RUN13 凍結ホールドアウト主確認

## 判定
**{verdict}**

## 主結果
- 凍結事象数: {len(table)}
- Spearman rho: {primary['rho']:.6f}
- exact片側p: {primary['exact_one_sided_p']:.8f}
- exact両側p: {primary['exact_two_sided_p']:.8f}
- 全列挙順列数: {primary['permutations']:,}
- alpha: {cfg['alpha']}

## 感度
- balanced observed W1: rho={balanced['rho']:.6f}, exact片側p={balanced['exact_one_sided_p']:.8f}
- 全8事象共通セル: {len(common_cells)}セル
- 共通セル full W1: rho={common_full['rho']:.6f}, exact片側p={common_full['exact_one_sided_p']:.8f}
- 共通セル balanced W1: rho={common_balanced['rho']:.6f}, exact片側p={common_balanced['exact_one_sided_p']:.8f}
- Kendall tau-b: {float(tau.statistic):.6f}
- leave-one-out rho範囲: {leave_one_out['rho'].min():.6f} ～ {leave_one_out['rho'].max():.6f}

## 境界
これは、RUN03の要約変動順位が、凍結済み8事象におけるv1→v2 posterior分布移動を
順位的に追跡したという限定的確認である。

ブラックホール物理の真値、特定波形モデルの正しさ、全GWTC-4母集団への一般化、
個々の事象の物理的異常を示すものではない。

8事象と主変数は事前凍結されたが、最終alphaと片側exact判定規則の明文化はRUN13作成時である。
したがって完全盲検の事前登録試験とは表現しない。
"""
    (OUT / "RUN13_CONFIRMATORY_REPORT.md").write_text(
        report_md, encoding="utf-8"
    )
    pd.DataFrame(columns=["error"]).to_csv(OUT / "ERROR_LEDGER.csv", index=False)
    (OUT / "RUN_STATUS.json").write_text(
        json.dumps(
            {
                "verdict": verdict,
                "exit_recommendation": 0,
                "confirmatory_test_executed_once": True,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
