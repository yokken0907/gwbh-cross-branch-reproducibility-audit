
from pathlib import Path
import csv
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def excluded(rel: str) -> bool:
    normalized = "/" + rel.replace("\\", "/") + "/"
    return (
        rel.startswith((".venv/", "deliverables/"))
        or "/.pytest_cache/" in normalized
        or "/__pycache__/" in normalized
    )

def included_files():
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = str(path.relative_to(ROOT))
        if excluded(rel):
            continue
        if path.name in {"MANIFEST.csv", "SHA256SUMS.csv"}:
            continue
        files.append(path)
    return sorted(files)

def write_manifests(files):
    rows = [
        {
            "path": str(path.relative_to(ROOT)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        for path in files
    ]
    for name in ("MANIFEST.csv", "SHA256SUMS.csv"):
        with (ROOT / name).open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"])
            writer.writeheader()
            writer.writerows(rows)

def main():
    base = included_files()
    write_manifests(base)
    files = included_files() + [ROOT / "MANIFEST.csv", ROOT / "SHA256SUMS.csv"]
    out = (
        ROOT
        / "deliverables"
        / "GWBHPIA_FROZEN_HOLDOUT_CONFIRMATORY_ANALYSIS_v0.13.0_RUN13_RESULTS_FOR_REVIEW.zip"
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(files):
            z.write(path, arcname=f"{ROOT.name}/{path.relative_to(ROOT)}")
    digest = sha256(out)
    Path(str(out) + ".sha256").write_text(
        f"{digest}  {out.name}\n", encoding="utf-8"
    )
    print(out)
    print(digest)

if __name__ == "__main__":
    main()
