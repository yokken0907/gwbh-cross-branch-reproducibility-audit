# RUN13 凍結ホールドアウト主確認契約

## 目的
RUN08終了時に凍結した未解析8事象について、要約表の変動指標 `median_s90` が、
posterior sampleのv1→v2分布移動を順位的に予測するかを一度だけ確認する。

## 主確認
- 対象：凍結済み8事象すべて
- 説明変数：RUN03 corrected の事象別 `median_s90`
- 応答変数：v1→v2、primary individual modelsにおける事象別
  `median_full_norm_W1`
- 統計量：Spearman順位相関係数
- 方向：正の関連
- p値：8! = 40,320通りを全列挙する片側exact permutation p値
- 判定基準：rho > 0 かつ exact片側p <= 0.05

## 感度監査
主判定を変更せず、以下を補助的に計算する。
1. balanced observed W1による同じ相関
2. 全8事象に共通するanalysis×parameterセルだけで再集計
3. exact両側p値
4. Kendall tau-b
5. 1事象ずつ除外したSpearman範囲
6. 四分位層ごとの応答中央値

## 開示上の境界
- 8事象、選定規則、順序、主説明変数、主応答変数はposterior取得前に凍結された。
- 一方、alpha=0.05と片側exact permutationという最終判定規則は、
  全バッチ処理後のRUN13作成時に明文化された。
- よって「完全な盲検事前登録試験」とは呼ばず、
  **凍結ホールドアウトによる限定的確認**と表現する。
- これは公開推論値の版間感度を示すものであり、
  ブラックホール物理の真値、波形モデルの正誤、観測事象の異常を直接示さない。
